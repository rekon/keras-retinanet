import glob
from subprocess import call

for name in glob.glob('*.xml'):
	
	new_name = name.strip().replace(' ','_')
	#print(new_name)
	call('ren "'+name+'" '+new_name, shell = True)